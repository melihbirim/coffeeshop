package com.kahveci.model;

public enum Option {
    NONE, COCONUT, NOFAT_MILK, WHOLE_MILK, XX_MILK, SOY
}
