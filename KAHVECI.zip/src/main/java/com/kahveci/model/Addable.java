package com.kahveci.model;

/**
 * A Marker interface for order
 */
interface Addable {
}
