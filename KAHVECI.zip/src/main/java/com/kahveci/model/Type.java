package com.kahveci.model;

public enum Type {
    ICED, ESPRESSO, TEA, BOTTLED, FILTERED
}