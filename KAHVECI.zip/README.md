## Simple Coffeshop Order example with Jersey, GSON and Embedded DB

* Assuming you're already installed maven and java8,(Please check your JAVA_HOME env. variable shows java8 directory)
* not required but nice to have a foreman

1. Clone this repo
2. cd into the directory
3. mvn clean package
4. mvn exec:java ---- or ---- foreman start